# const.py

DOMAIN = "command_sender"
SERVICE_SEND_COMMAND = "send_command"
